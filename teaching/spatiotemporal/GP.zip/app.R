## libraries ----
library(shiny)
library(mvtnorm)
library(lattice)
library(viridis)
library(scales)
library(RandomFields)
## UI ----
ui <- fluidPage(
    withMathJax(),
    tabsetPanel(type = "tabs",
                ## univariate ----
                tabPanel("univariate",
                         column(3,
                                h3("Options"),
                                sliderInput("N_univariate",
                                            "N",
                                            min = 1, max = 2e2,
                                            step = 1, value = 100),
                                sliderInput("var_univariate",
                                            "variance \\((\\sigma^2)\\)",
                                            min = -1, max = 1,
                                            step = 0.01, value = 0.7),
                                actionButton("resample_univariate", label = "Resample"),
                                p("Probability density function for mean-zero normal distribution:"),
                                p("\\(f(x) = \\frac{1}{\\sqrt{2\\pi\\sigma^2}}e^{-\\frac{x^2}{2\\sigma^2}} \\)"),
                                h3("Questions to consider:"),
                                p('1. Why are negative variances not allowed?')
                         ),
                         column(9, plotOutput("univariate_histogram"))
                ),
                ## bivariate ----
                tabPanel("bivariate",
                         column(3,
                                h3("Options"),
                                sliderInput("N_bivariate",
                                            "N",
                                            min = 1, max = 2e2,
                                            step = 1, value = 40),
                                sliderInput("rho_bivariate",
                                            "correlation \\((\\rho)\\)",
                                            min = -1, max = 1,
                                            step = 0.001, value = 0.7),
                                actionButton("resample_bivariate", label = "Resample"),
                                h3("Questions to consider:"),
                                p('1. What happens when you set the correlation to 1 or -1?'),
                                p('2. The top two plots are two different ways of plotting the same data. How does positive correlation show up in the top right plot?')
                         ),
                         column(9, 
                                fluidRow(
                                    h3("random process"),
                                    column(6, plotOutput("bivariate_scatter_plot")),
                                    column(6, plotOutput("bivariate_process_plot"))
                                ),
                                fluidRow(
                                    h3("covariance matrix"),
                                    column(12, plotOutput("bivariate_covariance_plot"))
                                )
                         )
                ),
                ## finite 1 dimension process ----
                tabPanel("finite 1 dimension process",
                         column(3,
                                h3("Options"),
                                sliderInput("N_one_d",
                                            "N",
                                            min = 1, max = 2e2,
                                            step = 1, value = 40),
                                sliderInput("M_one_d",
                                            "M",
                                            min = 1, max = 1e2,
                                            step = 1, value = 10),
                                sliderInput("rho_one_d",
                                            "correlation \\((\\rho)\\)",
                                            min = -1, max = 1,
                                            step = 0.001, value = 0.7),
                                radioButtons("cov_model_one_d", "Covariance model",
                                             choices = c("constant", "autoregressive"), 
                                             selected = "constant"),
                                actionButton("resample_one_d", label = "Resample"),
                                h3("Questions to consider:"),
                                p('1. For the constant covariance model, what happens to the plot of the random process as the correlation parameter tends toward 1? Why do you think that is?'),
                                p('2. What, if anything, do you think the colors help show about the effect of the correlation parameter on the random processes?')
                         ),
                         column(9, 
                                fluidRow(
                                    h3("random process"),
                                    column(12, plotOutput("one_d_process_plot"))
                                ),
                                fluidRow(
                                    h3("covariance matrix"),
                                    column(12, plotOutput("one_d_covariance_plot"))
                                )
                         )
                ),
                ## finite 2 dimension process ----
                tabPanel("finite 2 dimension process",
                         column(3,
                                h3("Options"),
                                sliderInput("N_two_d",
                                            "N",
                                            min = 1, max = 5e1,
                                            step = 1, value = 1),
                                sliderInput("M_two_d",
                                            "M",
                                            min = 1, max = 2e1,
                                            step = 1, value = 10),
                                sliderInput("rho_two_d",
                                            "correlation \\((\\rho)\\)",
                                            min = -1, max = 1,
                                            step = 0.001, value = 0.7),
                                radioButtons("cov_model_two_d", "Covariance model",
                                             choices = c("constant", "autoregressive"), 
                                             selected = "constant"),
                                actionButton("resample_two_d", label = "Resample"),
                                h3("Questions to consider:"),
                                p('1. What visually distinct feature shows up in the covariance matrix for the autoregressive covariance model? Why does this NOT happen in the one dimensional case?'),
                                p('2. What happens when you choose the constant covariance model and set the correlation parameter to something like -0.5? Why do you think this is?')
                         ),
                         column(9, 
                                fluidRow(
                                    h3("random process"),
                                    column(12, plotOutput("two_d_process_plot"))
                                ),
                                fluidRow(
                                    h3("covariance matrix"),
                                    column(12, plotOutput("two_d_covariance_plot"))
                                )
                         )
                ),
                ## continuous 1D Gaussian process ----
                tabPanel("continuous 1D Gaussian process",
                         column(3,
                                h3("Options"),
                                sliderInput("range_a",
                                            "spatial range \\((a)\\)",
                                            min = 1e-3, max = 1,
                                            step = 0.001, value = 0.1),
                                radioButtons("cov_model_one_d_cont", "Covariance model",
                                             choices = c("Gaussian", "exponential"), 
                                             selected = "Gaussian"),
                                actionButton("resample_one_d_cont", label = "Resample"),
                                h3("Questions to consider:"),
                                p('1. Which covariance model choice generates "smoother" processes?'),
                                p('2. What do you think happens to the random process as the range parameter approaches infinity?'),
                                p('3. What is something you noticed about continuous 1D Gaussian processes that you think others may not have?')
                         ),
                         column(9, 
                                fluidRow(
                                    h3("random process"),
                                    column(12, plotOutput("one_d_cont_process_plot"))
                                ),
                                fluidRow(
                                    h3("covariance function"),
                                    column(6, plotOutput("one_d_cont_covariance_plot")),
                                    column(6, plotOutput("one_d_cont_covariance_image"))
                                    )
                                
                         )
                ),
                ## continuous 2D Gaussian process ----
                tabPanel("continuous 2D Gaussian process",
                         column(3,
                                h3("Options"),
                                sliderInput("range_a_two_d",
                                            "spatial range \\((a)\\)",
                                            min = 1e-3, max = 1,
                                            step = 0.001, value = 0.1),
                                radioButtons("cov_model_two_d_cont", "Covariance model",
                                             choices = c("Gaussian", "exponential"), 
                                             selected = "Gaussian"),
                                actionButton("resample_two_d_cont", label = "Resample"),
                                h3("Questions to consider:"),
                                p('1. Which covariance model choice generates "smoother" processes?'),
                                p('2. The top two figures both provide visualizations of the random process. Which do you prefer? Why?'),
                                p('3. What is something you noticed about continuous 2D Gaussian processes that you think others may not have?')
                         ),
                         column(9, 
                                fluidRow(
                                    h3("random process"),
                                    column(6, plotOutput("two_d_cont_process_image")),
                                    column(6, plotOutput("two_d_cont_process_persp"))
                                ),
                                fluidRow(
                                    h3("covariance function"),
                                    column(6, plotOutput("two_d_cont_covariance_plot")),
                                    column(6, plotOutput("two_d_cont_covariance_persp"))
                                )
                         )
                )
    )
)


## server ----
server <- function(input, output) {
    ## reactiveValues ----
    z <- reactiveValues(univariate = NULL, bivariate = NULL, 
                        one_d = NULL, two_d = NULL, grid_two_d = NULL)
    Sigma <- reactiveValues(univariate = NULL, bivariate = NULL, one_d = NULL, two_d = NULL, 
                            one_d_cont = NULL, two_d_cont = NULL,
                            biv_NND = T, one_d_NND = T, two_d_NND = T)
    colors <- reactiveValues(bivariate = NULL, one_d = NULL, two_d = NULL,
                             one_d_cont = NULL, two_d_cont = NULL)
    ## univariate ----
    observeEvent(input$resample_univariate, {
        z$univariate <- rnorm(input$N_univariate, sd = sqrt(input$var_univariate))
        Sigma$univariate <- input$var_univariate
    }, ignoreNULL = F)
    output$univariate_histogram <- renderPlot({
        grid_univariate <- seq(sqrt(abs(Sigma$univariate)) * -3, sqrt(abs(Sigma$univariate)) * 3, l = 2e2)
        if(Sigma$univariate > 0){
            density_z <- dnorm(grid_univariate, sd = sqrt(Sigma$univariate))
            hist(z$univariate, prob = T, xlab = "", breaks = "Scott", main = "Histogram")
            rug(z$univariate)
            lines(grid_univariate, density_z)
        } else {
            plot(grid_univariate, 1/sqrt(2 * pi * -Sigma$univariate) * exp(-1/2 * grid_univariate^2 / Sigma$univariate), 
                 type = "l", ylab = "Density", xlab = "", main = "Invalid covariance")
        }
    })
    ## bivariate ----
    observeEvent(input$resample_bivariate, {
        Sigma$bivariate <- matrix(c(1, input$rho_bivariate, input$rho_bivariate, 1), 2, 2)
        Sigma_min_eigen <- min(eigen(Sigma$bivariate)$values)
        Sigma$biv_NND <- T
        if(Sigma_min_eigen < 0) Sigma$biv_NND <- F
        z$bivariate <- rmvnorm(input$N_bivariate, rep(0, 2), Sigma$bivariate)
        colors$bivariate <- viridis(input$N_bivariate)[rank(z$bivariate[, 1])]
    }, ignoreNULL = F)
    output$bivariate_scatter_plot <- renderPlot({
        plot(z$bivariate, col = colors$bivariate, xlab = "z(1)", ylab = "z(2)", axes = F)
    })
    output$bivariate_process_plot <- renderPlot({
        plot(1:2, ylim = c(-3, 3), type = 'n', ylab = "z(s)", xlab = "s", axes = F)
        axis(1, 1:2)
        N <- nrow(z$bivariate)
        segments(x0 <- rep(1, N), x1 = rep(2, N), 
                 y0 = z$bivariate[, 1], y1 = z$bivariate[, 2], 
                 col = colors$bivariate)
    })
    output$bivariate_covariance_plot <- renderPlot({
        if(Sigma$biv_NND){
            par(mar = c(0, 0, 1.2, 0))
            image(Sigma$bivariate, axes = F, main = expression(Sigma), asp = 1, cex.main = 2,
                  col = colorRampPalette(brewer_pal(palette = "BrBG")(11))(1e2), zlim = c(-1, 1))
        } else {
            plot(0, 0, type = "n", bty = "n", axes = F, xlab = "", ylab = "")
            text(0, 0, labels = "Warning: covariance matrix \n is NOT positive definite", xpd = T)
        }
    })
    ## one_d ----
    observeEvent(input$resample_one_d, {
        if(input$cov_model_one_d == "constant"){
            Sigma$one_d <- matrix(input$rho_one_d, input$M_one_d, input$M_one_d)
            diag(Sigma$one_d) <- 1
        } else if(input$cov_model_one_d == "autoregressive"){
            Sigma$one_d <- input$rho_one_d^as.matrix(dist(1:input$M_one_d, diag = T, upper = T))
        }
        Sigma_min_eigen <- min(eigen(Sigma$one_d)$values)
        Sigma$one_d_NND <- T
        if(Sigma_min_eigen < 0) Sigma$one_d_NND <- F
        z$one_d <- rmvnorm(input$N_one_d, rep(0, input$M_one_d), Sigma$one_d)
        colors$one_d <- viridis(input$N_one_d)[rank(z$one_d[, 1])]
    }, ignoreNULL = F)
    output$one_d_process_plot <- renderPlot({
        N <- nrow(z$one_d)
        M <- ncol(z$one_d)
        matplot(t(z$one_d), col = colors$one_d, type = "l", 
                axes = F, ylab = "z(s)", xlab = "s", lty = 1)
        axis(1, 1:M)
    })
    output$one_d_covariance_plot <- renderPlot({
        if(Sigma$one_d_NND){
            par(mar = c(0, 0, 1.2, 0))
            image(Sigma$one_d, axes = F, main = expression(Sigma), asp = 1, cex.main = 2,
              col = colorRampPalette(brewer_pal(palette = "BrBG")(11))(1e2), zlim = c(-1, 1))
        } else {
            plot(0, 0, type = "n", bty = "n", axes = F, xlab = "", ylab = "")
            text(0, 0, labels = "Warning: covariance matrix \n is NOT positive definite", xpd = T)
        }
    })
    ## two_d ----
    observeEvent(input$resample_two_d, {
        z$grid_two_d <- expand.grid(1:input$M_two_d, 1:input$M_two_d)
        dist_two_d <- as.matrix(dist(z$grid_two_d, diag = T, upper = T, method = "manhattan"))
        if(input$cov_model_two_d == "constant"){
            Sigma$two_d <- (dist_two_d == 0) + input$rho_two_d * (dist_two_d != 0)
        } else if(input$cov_model_two_d == "autoregressive"){
            Sigma$two_d <- input$rho_two_d^dist_two_d
        }
        Sigma_min_eigen <- min(eigen(Sigma$two_d)$values)
        Sigma$two_d_NND <- T
        if(Sigma_min_eigen < 0) Sigma$two_d_NND <- F
        z$two_d <- rmvnorm(input$N_two_d, rep(0, input$M_two_d^2), Sigma$two_d)
        colors$two_d <- viridis(input$N_two_d)[rank(z$two_d[, 1])]
    }, ignoreNULL = F)
    output$two_d_process_plot <- renderPlot({
        N <- nrow(z$two_d)
        M <- ncol(z$two_d)
        wire_df <- data.frame(x = z$grid_two_d[, 1], y = z$grid_two_d[, 2], z = c(t(z$two_d)), 
                              g = rep(1:N, rep(M, N)), col = rep(colors$two_d, rep(M, N)))
        wireframe(z ~ x + y, data = wire_df, zlim = c(-3, 3), col.regions = alpha(colors$two_d, 0.5),
                  groups = g, col.groups = alpha(colors$two_d, 0.5), col = colors$two_d, 
                  xlab = expression(s[1]), ylab = expression(s[2]), zlab = "z(s)")
    })
    output$two_d_covariance_plot <- renderPlot({
        if(Sigma$two_d_NND){
            par(mar = c(0, 0, 1.2, 0))
            image(Sigma$two_d, axes = F, main = expression(Sigma), asp = 1, cex.main = 2, 
                  col = colorRampPalette(brewer_pal(palette = "BrBG")(11))(1e2), zlim = c(-1, 1))
        } else {
            plot(0, 0, type = "n", bty = "n", axes = F, xlab = "", ylab = "")
            text(0, 0, labels = "Warning: covariance matrix \n is NOT positive definite", xpd = T)
        }
    })
    ## one_d_cont ----
    n_grid <- 3e2
    grid <- seq(0, 1, l = n_grid)
    dist_1d <- sapply(grid, function(s_i) (s_i - grid)^2)
    observeEvent(input$resample_one_d_cont, {
        if(input$cov_model_one_d_cont == "Gaussian"){
            Sigma$one_d_cont <- exp(-dist_1d / input$range_a^2)
        } else if(input$cov_model_one_d_cont == "exponential"){
            Sigma$one_d_cont <- exp(-sqrt(dist_1d) / input$range_a)
        }
        z$one_d_cont <- rmvnorm(1, sigma = Sigma$one_d_cont)
        colors$one_d_cont <- "gray"
    }, ignoreNULL = F)
    output$one_d_cont_process_plot <- renderPlot({
        plot(grid, z$one_d_cont, col = colors$one_d_cont, type = "l",
                ylab = "z(s)", xlab = "s", lty = 1, ylim = c(1, -1) * qnorm(0.001))
    })
    output$one_d_cont_covariance_plot <- renderPlot({
        plot(grid - 0.5, Sigma$one_d_cont[n_grid/2, ], type = "l", xlab = "distance", ylab = "covariance")
    })
    output$one_d_cont_covariance_image <- renderPlot({
        par(mar = c(0, 0, 1.2, 0))
        image(Sigma$one_d_cont, axes = F, main = expression(Sigma), asp = 1, cex.main = 2,
              col = colorRampPalette(brewer_pal(palette = "BrBG")(11))(1e2), zlim = c(-1, 1))
    })
    ## two_d_cont ----
    RFoptions(spConform = FALSE)
    n_grid_2d <- 1e2
    grid_2d_side <- seq(0, 1, l = n_grid_2d)
    observeEvent(input$resample_two_d_cont, {
        if(input$cov_model_two_d_cont == "Gaussian"){
            Sigma$two_d_cont <- RMgauss(scale = input$range_a_two_d)
        } else if(input$cov_model_two_d_cont == "exponential"){
            Sigma$two_d_cont <- RMexp(scale = input$range_a_two_d)
        }
        z$two_d_cont <- RFsimulate(model = Sigma$two_d_cont, x = grid_2d_side, y = grid_2d_side)
        colors$two_d_cont <- "gray"
    }, ignoreNULL = F)
    output$two_d_cont_process_image <- renderPlot({
        image(z$two_d_cont,
              col = colorRampPalette(brewer_pal(palette = "RdBu")(11))(1e2), 
              ylab = expression(s[2]), xlab = expression(s[1]), lty = 1, asp = 1)
    })
    output$two_d_cont_process_persp <- renderPlot({
        par(mar = c(0, 0, 0, 0))
        persp(z$two_d_cont, ylab = expression(s[2]), xlab = expression(s[1]), 
              theta = 30, phi = 30, zlim = c(1, -1) * qnorm(0.001))
    })
    output$two_d_cont_covariance_plot <- renderPlot({
        plot(Sigma$two_d_cont, xlim = c(-0.5, 0.5), 
             xlab = "distance", ylab = "covariance", main = "")
    })
    output$two_d_cont_covariance_persp <- renderPlot({
        par(mar = c(0, 0, 0, 0))
        persp(Sigma$two_d_cont, xlim = c(-0.5, 0.5), xlab = "s[1]", ylab = "s[2]", 
              main = "", theta = 30, phi = 30, n.points = 50)
    })
}

## Run the application ----
shinyApp(ui = ui, server = server)
