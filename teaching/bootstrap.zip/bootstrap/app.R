library(shiny)

# Define UI for application that draws a histogram
ui <- fluidPage(
    withMathJax(),
    h1("Non-parametric bootstrap"),
    fluidRow(
        column(
            width = 4,
            conditionalPanel(
                "input.q2_box == true", 
                h3("Data"),
                sliderInput("n", "n: number of observations",
                            min = 1, max = 1e3, step = 10,
                            round = T, value = 100),
                h4("Distribution for the data: Gamma(shape, scale)"),
                p("In real applications, ", em("we don't know this part.")),
                sliderInput("shape", "shape parameter",
                            min = 1e-2, max = 10, step = 0.1,
                            round = T, value = 2),
                sliderInput("scale", "scale parameter",
                            min = 1e-2, max = 10, step = 0.1,
                            round = T, value = 2),
                actionButton("resample_data", "Resample data"),
                conditionalPanel(
                    "input.q3_box == true", 
                    h3("Estimators"),
                    sliderInput("m", "m: number of MC (bootstrap) samples",
                                min = 2, max = 1e3, step = 2,
                                round = T, value = 100),
                    h4("Parametric bootstrap"),
                    checkboxGroupInput(
                        "par_dist", 
                        "Distribution:",
                        list(
                            "Gaussian" = "gaussian",
                            "Uniform" = "unif",
                            "Gamma" = "gamma",
                            "True Gamma" = "true_gamma"
                        ), "gaussian",
                    ),
                    actionButton("resample_par", "Resample parametric bootstrap"),
                    h4("Non-parametric bootstrap"),
                    actionButton("resample_nonpar", "Resample non-parametric bootstrap")
                )
            )
        ),
        column(
            width = 8,
            fluidRow(
                column(
                    width = 6,
                    plotOutput("data_plot")
                ),
                conditionalPanel(
                    "input.q3_box == true", 
                    column(
                        width = 6,
                        plotOutput("boot_plot")
                    )
                )
            ),
            fluidRow(
                h3("Questions:"),
                p("In this scenario, we're going to imagine that we're trying to better understand extreme wildfire behavior. The data shown in the rug plot + histogram represent measurements of fire severity for several wildfires gathered over several seasons. Large wildfire severity corresponds to hotter, more intense (though not necessarily larger) fires. The 95th quantile of fire severity represents a 20-year fire, or the level of severity we would only expect to excede only about once every 20 years. We don't know the true distribution of wildfires, so we can't know the exact 20-year fire, but we can use our sample of wildfire severities to estimate it.", style = "max-width: 1000px"), 
                p("1. Look at the histogram + rug plot shown and make a guess at the 95th quantile. You can decide on a single value, or even better, give a range of values you think are possible.", style = "max-width: 1000px"), 
                textInput(inputId = "q1_text", label = ""), 
                p("2. What is one risk of underestimating the 95th quantile in the context of fire severity? What is one risk of over estimating the 95th quantile?"),
                textAreaInput(inputId = "q2_text", label = NULL, width = "600px", height = "60px"), 
                checkboxInput("q2_box", "Done with 1 and 2."),
                conditionalPanel(
                    "input.q2_box == true", 
                    p("In this example, the data are simulated (surprise!) from a Gamma distribution. We can choose what the data look like by altering the corresponding shape and scale parameters, and we can specify how many realizations we observe (n).", style = "max-width: 1000px"),
                    p("3. Generate some new datasets from a Gamma(2, 2). How do you feel about your original answer to 1.?"),
                    textAreaInput(inputId = "q3_text", label = NULL, width = "600px", height = "60px"), 
                    checkboxInput("q3_box", "Done with 3."),
                    conditionalPanel(
                        "input.q3_box == true", 
                        p("We will compare several possible methods for computing a cofidence interval for the true 95th quantile. If it were possible to generate several batches of data, we could get a good confidence interval by just re-estimating the 95th quantile over and over and looking at the distribution of our estimators. In practice, we only get one batch of data, and we can't get more because we don't know the true data generating distribution. However, we might be willing to assume that the data come from one of a family of parameteric distributions (Gaussian, Uniform, etc.), in which case we could fit the parametric family to the data, and then draw several new batches from the fitted distribution. The top 3 parametric bootstrap distributions to the left are matched to the observed data using maximum likelihood." , style = "max-width: 1000px"),
                        p("4. Which parametric bootstrap distribution(s) tends to yield CIs closest to the one we get from repeated sampling from the true distribution ('T. Gamma')? Which distribution tends to be the most different?" , style = "max-width: 1000px"), 
                        textAreaInput(inputId = "q4_text", label = NULL, width = "600px", height = "60px"), 
                        p("5. Can you identify any situations where assuming the data are Gaussian reliably yields CIs that closely match the one produced by the idealized T. Gamma? What about for the Uniform distribution?" , style = "max-width: 1000px"),
                        textAreaInput(inputId = "q5_text", label = NULL, width = "600px", height = "60px"), 
                        checkboxInput("q5_box", "Done with 4 and 5."),
                        conditionalPanel(
                            "input.q5_box == true",
                            p("6. If we do not feel confident making a distributional assumption about the data, we can turn to the non-parametric bootstrap. For m = 2, the non-parametric boostrap is very erratic (try resampling over and over and watch the CI). Above what value of m does the non-parametric boostrap CI settle down? What does this suggest about the number of bootstrapped replicates needed for reliable inference?" , style = "max-width: 1000px"),
                            textAreaInput(inputId = "q6_text", label = NULL, width = "600px", height = "60px"), 
                            p("7. As n increases, three of the methods appear to converge to similar CIs. Which two do not? Why do you think this is?"),
                            textAreaInput(inputId = "q7_text", label = NULL, width = "600px", height = "60px"), 
                            p("8. What's one thing you noticed/learned from this shinyapp that others might not have?"),
                            textAreaInput(inputId = "q8_text", label = NULL, width = "600px", height = "60px")
                        )
                    )
                )
            ),
            fluidRow(
                conditionalPanel(
                    "input.q3_box == true", 
                    h3("Parametric bootstrap code:"),
                    code("x <- rgamma(n, shape, scale)", tags$br(),
                         "samps <- matrix(rnorm(m * n, mean = mean(x), sd = sd(x)), n, m)", tags$br(),
                         "ests <- apply(samps, 2, quantile, probs = 0.95)", tags$br(),
                         "quantile(ests, probs = c(0.025, 0.975))"),
                    conditionalPanel(
                        "input.q5_box == true", 
                        h3("Non-parametric bootstrap code:"),
                        code("x <- rgamma(n, shape, scale)", tags$br(),
                             "boot_samps <- matrix(sample(x, m * n, replace = T), n, m)", tags$br(),
                             "boot_ests <- apply(boot_samps, 2, quantile, probs = 0.95)", tags$br(),
                             "quantile(boot_ests, probs = c(0.025, 0.975))")
                    )
                )
            )
        )
    )
)

# Define server logic required to draw a histogram
server <- function(input, output) {
    colors <- c(unif = "#701c00", "#8c3800", "#a85400", gamma = "#c47000", "#c48c1c",
                true_gamma = "#e0a81c", "#e0c48c", "#e0e0e0", "#c4c4c4", "#8ca8c4",
                "#708ca8", nonpar = "#1c54a8", gaussian = "#385438", "#38381c")
    pars <- c('nonpar', 'gaussian', 'unif', 'gamma', 'true_gamma')
    get_ml_gamma <- function(x, init = c(2, 2)){
        optim(par = init, function(par, x){
            -sum(dgamma(x, par[1], par[2], log = T))
        }, x = x, method = "L-BFGS-B", lower = c(1e-1, 1e-1))$par
    }
    reactive_var <- reactiveValues(x = NULL, nonpar = NULL,
                                   par = list(gaussian = NULL, unif = NULL,
                                              gamma = NULL, true_gamma = NULL),
                                   densities = list(gaussian = NULL, unif = NULL,
                                                    gamma = NULL, true_gamma = NULL))
    observeEvent(input$resample_data, {
        reactive_var$x <- rgamma(input$n, input$shape, input$scale)
    }, ignoreNULL = F)
    observeEvent(input$resample_par & input$resample_data, {
        if("gaussian" %in% input$par_dist){
            reactive_var$densities[['gaussian']] <- function(x) dnorm(x, mean(reactive_var$x), sd(reactive_var$x))
            reactive_var$par[["gaussian"]] <- 
                matrix(rnorm(input$n * input$m, mean(reactive_var$x), sd(reactive_var$x)), 
                       input$n, input$m)
        } else {
            reactive_var$densities[['gaussian']] <- reactive_var$par[["gaussian"]] <- NULL
        }
        if("unif" %in% input$par_dist){
            reactive_var$densities[['unif']] <- function(x) dunif(x, min(reactive_var$x), max(reactive_var$x))
            reactive_var$par[["unif"]] <- 
                matrix(runif(input$n * input$m, min(reactive_var$x), max(reactive_var$x)), 
                       input$n, input$m)
        } else {
            reactive_var$densities[['unif']] <- reactive_var$par[["unif"]] <- NULL
        }
        if("gamma" %in% input$par_dist){
            gamma_params <- get_ml_gamma(reactive_var$x)
            reactive_var$densities[['gamma']] <- function(x) dgamma(x, gamma_params[1], gamma_params[2])
            reactive_var$par[["gamma"]] <- 
                matrix(rgamma(input$n * input$m, gamma_params[1], gamma_params[2]), 
                       input$n, input$m)
        } else {
            reactive_var$densities[['gamma']] <- reactive_var$par[["gamma"]] <- NULL
        }
        if("true_gamma" %in% input$par_dist){
            reactive_var$densities[['true_gamma']] <- function(x) dgamma(x, input$shape, input$scale)
            reactive_var$par[["true_gamma"]] <- 
                matrix(rgamma(input$n * input$m, input$shape, input$scale), 
                       input$n, input$m)
        } else {
            reactive_var$densities[['true_gamma']] <- reactive_var$par[["true_gamma"]] <- NULL
        }
    })
    observeEvent(input$resample_nonpar, {
        reactive_var$nonpar <- 
            matrix(sample(reactive_var$x, input$m * input$n, replace = T), input$n, input$m)
    }, ignoreInit = T)
    get_x_seq <- reactive({
        pretty_breaks <- pretty(reactive_var$x)
        seq(pretty_breaks[1], pretty_breaks[length(pretty_breaks)], l = 2e2)
    })
    get_pt_ets <- reactive({
        pt_ests <- list()
        if(!is.null(reactive_var$nonpar))
            pt_ests[["nonpar"]] <- apply(reactive_var$nonpar, 2, quantile, probs = 0.95)
        n_par <- length(reactive_var$par)
        if(n_par > 0){
            for(i in 1:n_par){
                pt_ests[[names(reactive_var$par)[i]]] <- 
                    apply(reactive_var$par[[i]], 2, quantile, probs = 0.95)
            }
        }
        return(pt_ests)
    })
    ## plots ----
    output$data_plot <- renderPlot({
        x_seq <- get_x_seq()
        hist(reactive_var$x, freq = F, xlab = "wildfire severity", main = "Data", breaks = "FD")
        rug(reactive_var$x)
        if(length(reactive_var$densities) > 0){
            sapply(1:length(reactive_var$densities), function(i){
                lines(x_seq, reactive_var$densities[[i]](x_seq), lwd = 2, xpd = T,
                      col = colors[names(reactive_var$densities)[i]])
            })
        }
    })
    output$boot_plot <- renderPlot({
        pt_ests <- get_pt_ets()
        boxplot(vector("list", 5), ylim = range(qgamma(0.95, input$shape, input$scale), pt_ests[pars], na.rm = T),
                col = NULL, border = NA, main = "Confidence intervals",
                names = c("Non-par", "Gauss", "Unif", "Gamma", "T. Gamma"))
        for(par in pars){
            i <- which(par == pars)
            ul <- quantile(pt_ests[[par]], probs = c(0.025, 0.975))
            rect(xleft = i - 0.1, xright = i + 0.1,
                 ybottom = ul[1], ytop = ul[2],
                 col = colors[[par]])
        }
        abline(h = qgamma(0.95, input$shape, input$scale), lwd = 2, lty = 2)
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
