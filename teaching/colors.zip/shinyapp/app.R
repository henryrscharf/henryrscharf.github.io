library(shiny)
# ui ----
ui <- fluidPage(
    theme = bslib::bs_theme(bootswatch = "flatly"),
    withMathJax(),
    h2("Choosing better colors"),
    h4("Work with your group to answer the questions on each tab of this shinyapp.", em("Record your answers and be ready to share.")), br(),
    tabsetPanel(
        id = "nav",
        ## 1 ----
        tabPanel(
            "1. What's wrong with these?",
            # h3("text"),
            h5("As clearly as you can, explain why each graphic is confusing/misleading/unappealing. What is it about the colors specifically that could be improved?"),
            br(),
            fluidRow(
                column(6, p("Figure (a) Seminar flyer."),
                       img(src = "flyer.png", width = "100%", style = "padding:0 60px 60px 60px")),
                column(6, p("Figure (b) Map of log-population of San Diego by Census tract."),
                       plotOutput("CA_map_div"))
            ),
            fluidRow(
                column(6, p("Figure (c) Density of lightning flashes in northern Colorado."),
                       a(href = "https://agupubs.onlinelibrary.wiley.com/doi/full/10.1002/2015JD024663", target = "_blank",
                         img(src = "lightning_CO.png", width = "75%", style = "padding:0 60px 60px 60px"))),
                column(6, p("Figure (d) Six possible fitted relationships between population and log-tract area."),
                       plotOutput("curves"))
            )
        ),
        ## 2 ----
        tabPanel(
            "2. Implementation: code for color in R",
            h5("This plot shows the residuals from a linear model for log-population as a function of log-tract area. We're going to work through some code to re-produce the plot."), 
            plotOutput("residuals"),
            h5("I've already fit this simple model (", code("lm(log(population) ~ log_area, data = sd)"), "), and stored the", code("residuals"), "in the file code", ("sd_pop.RData"), ". In the spaces provided to input code below, you can assume", code("sd_pop.RData"), "has already been loaded."),
            h5("(a) Try typing", code("head(residuals)"), "in the box provided to see the first few values."),
            textInput("test_code", label = NULL, placeholder = "try your code here", width = "100%"),
            submitButton("submit"),
            verbatimTextOutput("test_code_user"),
            
            h5("To make the plot shown with a gradient of colors applied to the points, we'll need to learn how to interpolate colors in", code("R"), ". First, let's get some decent colors to work with. The", code("RColorBrewer"), "package contains all the colors found at", a("https://colorbrewer2.org", href = "https://colorbrewer2.org"), ". The colors in the plot above are based on the diverging palette PuOr."),
            h5("(b) Look up the documentation for the function", code("brewer.pal()"), "an use it to print out the colors in the 9-class PuOr palette. Verify your printout below matches the color codes at", a("https://colorbrewer2.org", href = "https://colorbrewer2.org"), "."),
            textInput("PuOr_code", label = NULL, placeholder = "try your code here", width = "100%"),
            submitButton("submit"),
            verbatimTextOutput("PuOr_code_user"),

            h5("For us, 9 colors isn't enough--we need a continuum, or a gradient, of colors! The functions", code("colorRamp()"), "and", code("colorRampPalette()"), "are good at interpolating a few colors to make several."),
            h5("(c) Look up the documentation for the functions", code("colorRamp()"), "and", code("colorRampPalette()"), ". Choose the appropriate one and use it to make a function", "called", code("ramp()"), "that interpolates the nine-color diverging purple-orange", "palette from the", code("RColorBrewer"), "package for inputs between 0 and 1. Verify your output matches mine."),
            verbatimTextOutput("ramp_check_code"),
            verbatimTextOutput("ramp_check"),
            textAreaInput("ramp_code", label = NULL, placeholder = "try your code here", height = "150px", width = "100%"),
            submitButton("submit"),
            verbatimTextOutput("ramp_code_user"),

             h5("Now we've got another issue. The three numbers returned by", code("ramp()"), "are the (R)ed, (G)reen, and (B)lue values, not the codes we used before. To transform the RGB representation into a hexadecimal form that can be use by plotting functions in R, there is the function", code("rgb()"), "."), 
            h5("(d) Use", code("rgb()"), "to transform the output of", code("ramp(0.25)"), " (hint: you will need to adjust the argument", code("maxColorValue"), "). Check that your output matches mine."),
            verbatimTextOutput("rgb_check_code"),
            verbatimTextOutput("rgb_check"),
            textInput("rgb_code", label = NULL, placeholder = "try your code here"),
            submitButton("submit"),
            verbatimTextOutput("rgb_code_user"),
            
            h5("Now we have a function", code("ramp()"), "that returns purple colors for values close to 0, an orange colors for values close to 1, represented in RGB. We also know how to convert RGB to the hexidecimal form, which can be passed to the", code("col = "), "argument of the", code("plot()"), "function. We're ready to assign colors to all the values in the variable", code("residuals"), ". Before we can do that, we need to transform the raw residual values to the unit interval [0, 1] so we can use our", code("ramp()"), "function."),
            h5("The following code makes a function called", code("standardize"), "that maps a vector of values to [0, 1] such that an input of 0 returns 0.5. Using this function to transform the residuals will mean our diverging color gradient is centered at 0. Try it out with other vectors of values to see how it works."),
            verbatimTextOutput("std_blank_code"),
            verbatimTextOutput("std_check_code"),
            verbatimTextOutput("std_check"),
            textAreaInput("std_code", label = NULL, placeholder = "try your code here", height = "100px", width = "100%"),
            submitButton("submit"),
            verbatimTextOutput("std_code_user"),
            
            h5("Let's try to put this together to make the figure."),
            h5("(f) Make a vector called", code("std_resid"), "that contains the standardize residuals. Then use your", code("ramp()"), "function to map each residual to an RGB color. Finally, use", code("rgb()"), "to generate a final vector of the same length as", code("residuals"), "called", code("pt_colors"), "that has a color for each point in hexidecimal form. Check that the head of your", code("pt_colors"), "matches mine."), 
            verbatimTextOutput("pt_colors_check_code"),
            verbatimTextOutput("pt_colors_check"),
            textInput("pt_colors_code", label = NULL, placeholder = "try your code here"),
            submitButton("submit"),
            verbatimTextOutput("pt_colors_code_user"),
            
            h5("You should now be able to make the plot above using", code('plot(residuals, col = pt_colors, pch = 16, ylab = "residual")'), "."),
            textAreaInput("plot_code", label = NULL, width = "100%", height = "100px"),
            submitButton("submit"),
            plotOutput("plot_resid_user")
        ),
        ## 3 ----
        tabPanel(
            "3. Fix up some figures from the first tab.",
            h5("We're going to try and improve upon the two figures shown below. To help you try things out, load the variables stored in", code("sd_pop.RData"), "on your own machine. The variable", code("sd"), "is a dataframe containing the", code("population"), "and", code("log-area"), "of each census tract in the County of San Diego, along with polygons that represent the boundaries of each tract. As you've already seen, the variable", code("residuals"), "is a vector of residuals from a linear regression that predicts population based on log-area. Finally, the variable", code("predictions"), "is a dataframe giving the predicted relationship between log-area and population based the linear model (", code("lm"), "), three different polynomial functions, and two constrained non-parametric functions."),
            h5("(a) Fill in the blanks in the following code to reproduce the plot shown."),
            verbatimTextOutput("code_ggplot"),
            plotOutput("CA_map_bad", width = "100%", height = "500px"),
            h5("(b) Once you've duplicated the plot shown,", "write your own version of the code with better colors (hint: there are", em("lots"), "of", code("scale_fill_*()"), "type functions)."),
            textAreaInput("map_code", label = NULL, placeholder = "try your code here", height = "150px", width = "100%"),
            submitButton("submit"),
            plotOutput("CA_map_user", width = "100%", height = "600px"),
            
            h5("(c) Fill in the blanks in the following code to reproduce the plot shown."),
            verbatimTextOutput("curves_blank"),
            plotOutput("curves2", width = "100%", height = "500px"),
            h5("(d) Once you've duplicated the plot shown,", "write your own version of the code with better colors."),
            textAreaInput("curves_code", label = NULL, placeholder = "try your code here", 
                          height = "150px", width = "100%"),
            submitButton("submit"),
            plotOutput("curves_user", width = "100%", height = "600px")
        )
    )
)

        # ## 4 ----
        # tabPanel(
        #     "4. Match the palette and the plot",
        #     h5("(1) (a)--(c)..."),
        #     fluidRow(
        #         column(4, plotOutput("match_plot1"), 
        #                code("some code")),
        #         column(4, plotOutput("match_plot2")),
        #         column(4, plotOutput("match_plot3"))
        #     )
        # ),
# server ----
server <- function(input, output) {
    ## libraries ----
    library(ggplot2)
    library(sf)
    library(RColorBrewer)
    ## data ----
    load("sd_pop.RData")
    ## general calculations ----
    ramp_internal <- colorRamp(brewer.pal(9, "PuOr"))
    standardize <- function(x) (x / max(abs(x)) + 1) / 2
    pt_colors_internal <- rgb(ramp_internal(standardize(residuals)), max = 255)
    ## code checks for 2 ----
    output$test_code_user <- renderPrint({
      eval(parse(text = input$test_code))
    })
    output$PuOr_code_user <- renderPrint({
      eval(parse(text = input$PuOr_code))
    })
    output$ramp_code_user <- renderPrint({
        eval(parse(text = input$ramp_code))
    })
    output$ramp_check_code <- renderText({
        'ramp(0.25)'
    })
    output$ramp_check <- renderPrint({
        ramp_internal(0.25)
    })
    output$rgb_code_user <- renderPrint({
        eval(parse(text = input$ramp_code))
        eval(parse(text = input$rgb_code))
    })
    output$rgb_check_code <- renderText({
        'rgb(..., maxColorValue = ...)'
    })
    output$rgb_check <- renderPrint({
        rgb(ramp_internal(0.25), max = 255)
    })
    output$std_blank_code <- renderText({
'standardize <- function(x){
  (x / max(abs(x)) + 1) / 2
}'
    })
    output$std_code_user <- renderPrint({
        eval(parse(text = input$ramp_code))
        eval(parse(text = input$std_code))
    })
    output$std_check_code <- renderText({
        'standardize(-4:3)'
    })
    output$std_check <- renderPrint({
      standardize(-4:3)
    })
    output$pt_colors_check_code <- renderText({
      'head(pt_colors)'
    })
    output$pt_colors_check <- renderPrint({
      head(pt_colors_internal)
    })
    output$pt_colors_code_user <- renderPrint({
      eval(parse(text = input$ramp_code))
      eval(parse(text = input$std_code))
      eval(parse(text = input$pt_colors_code))
    })
    output$residuals <- renderPlot({
        plot(residuals, col = pt_colors_internal, pch = 16, ylab = "residual")
    })
    output$plot_resid_user <- renderPlot({
        eval(parse(text = input$ramp_code))
        eval(parse(text = input$std_code))
        eval(parse(text = input$plot_code))
    })
    ## CA map ----
    output$CA_map_div <- renderPlot({
        ggplot(aes(fill = log(population)), data = sd) + 
            geom_sf() +
            coord_sf(xlim = c(-117.4, -116.6), ylim = c(32.55, 33)) +
            scale_fill_distiller(palette = "RdYlBu") + 
            labs(fill = "log-population")
    }, res = 96)
    output$CA_map_bad <- renderPlot({
        ggplot(aes(fill = log(population)), data = sd) + 
            geom_sf(col = "red") + 
            coord_sf(xlim = c(-117.4, -116.6), ylim = c(32.55, 33)) + 
            scale_fill_continuous(low = "white", high = "black") + 
            labs(fill = "log-population")
    }, res = 96)
    
    output$code_ggplot <- renderText({
'library(ggplot2)
library(sf)
load("/path/to/sd_pop.RData")
ggplot(aes(_____ = log(population)), data = _____) + 
  geom_sf(col = _____) + 
  coord_sf(_____ = c(-117.4, -116.6), ylim = c(32.55, 33)) + 
  scale_fill______(low = "white, high = _____) + 
  labs(_____ = "log-population")'
    })
    output$CA_map_user <- renderPlot({
        eval(parse(text = input$map_code))
    })
    ## regression curves ----
    output$curves_blank <- renderText({
'load("/path/to/sd_pop.RData")
lwd = 3
colors <- brewer.pal(9, name = "Blues")[4:9]
plot(population ~ _____, data = _____, xlab = "_____", ylab = "log-population",
     col = "gray60", main = "Regressing log-population on log-tract area")
lines(lm ~ _____, data = _____, lwd = lwd, col = colors[6])
lines(poly2 ~ _____, data = predictions, lwd = lwd, col = colors[1])
lines(poly4 ~ log_area, data = predictions, lwd = lwd, col = colors[_____])
lines(_____ ~ log_area, data = predictions, lwd = lwd, col = colors[_____])
lines(_____ ~ log_area, data = predictions, lwd = lwd, col = colors[4])
lines(cgam_smooth ~ log_area, data = predictions, lwd = lwd, col = colors[5])
legend("topright", ncol = 2, col = _____, lwd = lwd, lty = 1, bty = "n",
       legend = c("deg. 2", "deg. 4", "deg. 6", "constrained", "constrained + smooth", "linear"))'
    })
    output$curves <- renderPlot({
        par(mar = c(4.1, 4.1, 4.1, 1.1))
        lwd = 3
        colors <- brewer.pal(9, name = "Blues")[4:9]
        plot(population ~ log_area, data = sd, xlab = "log-area", ylab = "log-population",
             col = "gray60", main = "Regressing log-population on log-tract area")
        lines(lm ~ log_area, data = predictions, lwd = lwd, col = colors[6])
        lines(poly2 ~ log_area, data = predictions, lwd = lwd, col = colors[1])
        lines(poly4 ~ log_area, data = predictions, lwd = lwd, col = colors[2])
        lines(poly6 ~ log_area, data = predictions, lwd = lwd, col = colors[3])
        lines(cgam ~ log_area, data = predictions, lwd = lwd, col = colors[4])
        lines(cgam_smooth ~ log_area, data = predictions, lwd = lwd, col = colors[5])
        legend("topright", ncol = 2, col = colors, lwd = lwd, lty = 1, bty = "n",
               legend = c("deg. 2", "deg. 4", "deg. 6", "constrained", "constrained + smooth", "linear"))
    })
    output$curves2 <- renderPlot({
        par(mar = c(4.1, 4.1, 4.1, 1.1))
        lwd = 3
        colors <- brewer.pal(9, name = "Blues")[4:9]
        plot(population ~ log_area, data = sd, xlab = "log-area", ylab = "log-population",
             col = "gray60", main = "Regressing log-population on log-tract area")
        lines(lm ~ log_area, data = predictions, lwd = lwd, col = colors[6])
        lines(poly2 ~ log_area, data = predictions, lwd = lwd, col = colors[1])
        lines(poly4 ~ log_area, data = predictions, lwd = lwd, col = colors[2])
        lines(poly6 ~ log_area, data = predictions, lwd = lwd, col = colors[3])
        lines(cgam ~ log_area, data = predictions, lwd = lwd, col = colors[4])
        lines(cgam_smooth ~ log_area, data = predictions, lwd = lwd, col = colors[5])
        legend("topright", ncol = 2, col = colors, lwd = lwd, lty = 1, bty = "n",
               legend = c("deg. 2", "deg. 4", "deg. 6", "constrained", "constrained + smooth", "linear"))
    })
    output$curves_user <- renderPlot({
        eval(parse(text = input$curves_code))
    })
    # ## plot matching ----
    # output$match_plot1 <- renderPlot({
    #     plot(1:9, col = RColorBrewer::brewer.pal(9, "Reds"), pch  = 16, cex = 2)
    # })
    # output$match_plot2 <- renderPlot({
    #     plot(1:9, col = RColorBrewer::brewer.pal(9, "Blues"), pch  = 16, cex = 2)
    # })
    # output$match_plot3 <- renderPlot({
    #     plot(1:9, col = RColorBrewer::brewer.pal(9, "Greens"), pch  = 16, cex = 2)
    # })
}

# Run the application 
shinyApp(ui = ui, server = server)
