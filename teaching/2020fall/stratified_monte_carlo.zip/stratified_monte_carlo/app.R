library(shiny)

# ui ----
ui <- fluidPage(
    withMathJax(),
    fluidRow(
        ## data, overall settings ----
        column(
            width = 4,
            h3("Integrand"),
            radioButtons("integrand",
                         "",
                         c("$$\\frac{e^{-x}}{1 + x^2}$$" = "6_11",
                           "$$\\frac{1}{2} + \\frac{\\cos(2 \\pi (x + \\frac{\\pi}{2}))}{4} + 
                           \\frac{\\sin(8 \\pi x)}{4}$$" = "trig",
                           "step function" = "step")),
            h3("Sample size (m)"),
            sliderInput("m", "",
                        min = 0, max = 1e3, step = 10,
                        round = T, value = 100),
            h3("Number of samples per stratum"),
            radioButtons("strata_size", "", 
                         c("equal" = "equal", 
                           "proportional to width" = "prop")),
            actionButton("resample", "Resample Non-stratified"),
            actionButton("set_strata", "Set/Resample Stratification"),
            actionButton("reset_strata", "Clear Stratification"),
            h3("Importance function: Beta(a, b)"),
            sliderInput("a", "a", min = 1e-1, max = 5, value = 1),
            sliderInput("b", "b", min = 1e-1, max = 5, value = 1)
        ),
        ## plot settings ----
        column(
            width = 8,
            h3("Instructions:"),
            p("The top plot shows the function to be integrated, the importance function, and rug plots showing the location of the Monte Carlo (MC) samples. To set strata boundaries, click on the top plot. When you have added all the strata you want, click 'Set/Resample Stratification.' The bottom plot shows 95% confidence intervals for each estimate of the integral."),
            p("The importance function is a Beta distribution with adjustable parmeters. **Make sure to click** 'Resample Non-stratified' and, if applicable, 'Set/Resample Stratification' after adjusting the importance function parameters."),
            ## questions ----
            h3("Questions:"),
            p("1. Choose the top integrand function. What parameter values in the Beta(a, b) importance function seem to provide the most precise estimate?"), 
            p("2. Set boundaries to create 5 approximately equal-sized strata, and choose 'equal' strata sizes (same number of draws per strata). Click 'Set/Resample Stratification' and look at the resulting CIs. How does stratified MC do compared to simple MC? How does stratified importance sampling (IS) compare  to non-stratified IS? Can you find a set of 5 unequal strata that outperforms equal-sized strata?"),
            p("3. Choose the step function integrand. Choose a sample size a little less than 100, and set three strata boundaries at the change points in the step function. Click 'Set/Resample Stratification' several times and observe the width of the stratified estimates. What do you notice? Why might this be happening?"),
            p("4. What stratification scheme seems to work best for the second integrand (the sum of trigonometric functions)?"),
            p("5. What is one thing you noticed from your explorations that you think others may not have noticed?"),
            ## MC plot ----
            fluidRow(
                plotOutput("MCPlot", click = "plot_click")
            ),
            ## CI plot ----
            fluidRow(
                plotOutput("CIPlot")
            )
        )
    )
)


# server ----
server <- function(input, output) {
    ## helpers ----
    colors <- c("#701c00", "#8c3800", "#a85400", "#c47000", "#c48c1c",
                "#e0a81c", "#e0c48c", "#e0e0e0", "#c4c4c4", "#8ca8c4",
                "#708ca8", "#1c54a8", "#385438", "#38381c")
    x_seq <- seq(1e-3, 1 - 1e-3, l = 2e2)
    strata_IS_sample <- function(n, left, right, a, b, batch_size = 100){
        if(left <= 0) left <- 1e-3
        if(right >= 1) right <- 1 - 1e-3
        n_out <- 0
        out <- NULL
        K <- diff(pbeta(c(left, right), a, b))
        c <- max(dbeta(seq(left, right, l = 1e4), a, b)) / K
        while(n_out < n){
            proposals <- runif(batch_size, left, right)
            accepted <- runif(batch_size) < (dbeta(proposals, a, b) / K / c)
            out <- c(out, proposals[which(accepted)])
            n_out <- n_out + sum(accepted)
        }
        return(out[1:n])
    }
    get_IS_K <- reactive({
        sapply(1:strata$J, function(j){
            diff(pbeta(strata$x[0:1 + j], input$a, input$b))
        })
    })
    get_integrand <- reactive({
        if(input$integrand == "step")
            return(function(x){
                (x > 0) * (x < 1) * (
                    0.3 * (x < 0.33) + 
                        0.8 * (x >= 0.33) * (x < 0.5) + 
                        0.2 * (x >= 0.5) * (x < 0.7) + 
                         0.3 * (x >= 0.7)
                )
            })
    if(input$integrand == "6_11")
            return(function(x) exp(-x) / (1 + x^2))
        if(input$integrand == "trig")
            return(function(x) (2 + cos(2 * pi * x + pi) + sin(4 * 2 * pi * x)) / 4)
    })
    get_true_value <- reactive({
        g <- get_integrand()
        x_grid <- seq(0, 1, l = 1e4)
        sum(g(x_grid)) * diff(x_grid[1:2])
    })
    ## non-stratified samples ----
    simple <- reactiveValues(MC = NULL, IS = NULL)
    observeEvent(input$resample, {
        simple$MC <- sort(runif(input$m))
        simple$IS <- sort(rbeta(input$m, input$a, input$b))
    }, ignoreNULL = F)
    ## MC estimate
    get_MC_est <- reactive({
        g <- get_integrand()
        g_x <- g(simple$MC)
        est <- mean(g_x)
        se <- sd(g_x) / sqrt(input$m)
        return(list(est = est, se = se, x = simple$MC))
    })
    ## IS estimate ----
    get_IS_est <- reactive({
        g <- get_integrand()
        g_star_x <- g(simple$IS) / dbeta(simple$IS, input$a, input$b)
        est <- mean(g_star_x)
        se <- sd(g_star_x) / sqrt(input$m)
        return(list(est = est, se = se, x = simple$IS))
    })
    ## stratified simple MC ----
    ## generate stratified MC sample
    strata <- reactiveValues(J = 1, x = 0:1, x_tmp = 0:1, 
                             sample = list(), sample_IS = list())
    observeEvent(input$plot_click$x, {
        strata$x_tmp <- sort(c(strata$x_tmp, input$plot_click$x))
        })
    observeEvent(input$set_strata, {
        strata$x <- strata$x_tmp
        strata$J <- length(strata$x) - 1
        if(input$strata_size == "equal"){
            strata$sample <- lapply(1:strata$J, function(j){
                runif(n = floor(input$m / strata$J), 
                      min = strata$x[[j]], max = strata$x[[j + 1]])
            })
            strata$sample_IS <- lapply(1:strata$J, function(j){
                strata_IS_sample(floor(input$m / strata$J), 
                                 left = strata$x[j], right = strata$x[j + 1], 
                                 a = input$a, b = input$b)
            })
        } else if(input$strata_size == "prop"){
            strata$sample <- lapply(1:strata$J, function(j){
                runif(n = floor(input$m * diff(strata$x[0:1 + j])), 
                      min = strata$x[[j]], max = strata$x[[j + 1]])
            })
            strata$sample_IS <- lapply(1:strata$J, function(j){
                strata_IS_sample(floor(input$m * diff(strata$x[0:1 + j])), 
                                 left = strata$x[j], right = strata$x[j + 1], 
                                 a = input$a, b = input$b)
            })
        }
    })
    observeEvent(input$reset_strata, {
        strata$J <- 1
        strata$x_tmp <- 0:1
        strata$x <- 0:1
        strata$sample <- list()
        strata$sample_IS <- list()
    })
    ## strata MC estimate
    get_strata_MC_est <- reactive({
        if(length(strata$sample) == 0)
            return(list(est = NULL, se = NULL))
        g <- get_integrand()
        g_x <- lapply(strata$sample, g)
        ests <- sapply(g_x, mean) * diff(strata$x)
        vars <- sapply(g_x, var) / sapply(strata$sample, length) * diff(strata$x)^2
        return(list(est = sum(ests), se = sqrt(sum(vars))))
    })
    ## strata IS ----
    ## strata MC estimate
    get_strata_IS_est <- reactive({
        if(length(strata$sample) == 0)
            return(list(est = NULL, se = NULL))
        g <- get_integrand()
        Ks <- get_IS_K()
        g_star_x <- lapply(1:strata$J, function(j){
            x <- strata$sample_IS[[j]]
            g(x) / dbeta(x, input$a, input$b) * Ks[j]
        })
        ests <- sapply(g_star_x, mean)
        vars <- sapply(g_star_x, var) / sapply(strata$sample_IS, length)
        return(list(est = sum(ests), se = sqrt(sum(vars))))
    })
    ## function plot ----
    output$MCPlot <- renderPlot({
        g <- get_integrand()
        f_x <- dbeta(x_seq, input$a, input$b)
        plot(x_seq, g(x_seq), type = "l", ylab = "g(x)", xlab = "x", ylim = c(0, 1.1), lwd = 2)
        lines(x_seq, f_x / max(f_x), lwd = 2, col = colors[12])
        rug(simple$MC, ticksize = 0.05, col = colors[5])
        rug(simple$IS, ticksize = 0.05, col = colors[12], side = 3)
        if(length(strata$sample) > 0){
            for(j in 1:strata$J){
                rug(strata$sample[[j]], col = colors[7], ticksize = 0.1)
            }
        }
        if(length(strata$sample_IS) > 0){
            for(j in 1:strata$J){
                rug(strata$sample_IS[[j]], col = colors[10], ticksize = 0.1, side = 3)
            }
        }
        abline(v = strata$x_tmp, lty = 2)
        legend(0.5, 1.25, xjust = 0.5, lty = 1, lwd = 2, col = c("black", colors[12]), 
               horiz = T, bty = "n", xpd = T,
               legend = c("g(x); integrand", "f(x); importance function"))
    })
    ## CI plot ----
    output$CIPlot <- renderPlot({
        truth <- get_true_value()
        MC_est <- get_MC_est()
        strata_MC_est <- get_strata_MC_est()
        IS_est <- get_IS_est()
        strata_IS_est <- get_strata_IS_est()
        x_range <- range(truth, MC_est$est + 1.96 * c(-1, 1) * MC_est$se, 
                         IS_est$est + 1.96 * c(-1, 1) * IS_est$se,
                         strata_MC_est$est + 1.96 * c(-1, 1) * strata_MC_est$se,
                         strata_IS_est$est + 1.96 * c(-1, 1) * strata_IS_est$se)
        xlims <- max(abs(x_range - truth)) * c(-1, 1) + truth
        plot(truth, 0, xlim = xlims, ylim = c(0, 1), 
             yaxt = "n", ylab = "", xlab = "", bty = "n", type = "n")
        ## strata_MC
        if(!is.null(strata_MC_est$est)){
            if(strata_MC_est$se == 0){
                segments(x0 = strata_MC_est$est, y0 = 0.6, y1 = 1, lwd = 3, col = colors[12])
            } else {
                rect(xleft = strata_MC_est$est - 1.96 * strata_MC_est$se, ybottom = 0.6,
                 xright = strata_MC_est$est + 1.96 * strata_MC_est$se, ytop = 1,
                 col = colors[7], border = NA)
            }
        }
        ## MC
        rect(xleft = MC_est$est - 1.96 * MC_est$se, ybottom = 0.7, 
             xright = MC_est$est + 1.96 * MC_est$se, ytop = 0.9, 
             col = colors[5], border = NA)
        ## strata IS
        if(!is.null(strata_IS_est$est)){
            if(strata_IS_est$se == 0){
                segments(x0 = strata_IS_est$est, y0 = 0, y1 = 0.4, lwd = 3, col = colors[10])
            } else {
            rect(xleft = strata_IS_est$est - 1.96 * strata_IS_est$se, ybottom = 0,
                 xright = strata_IS_est$est + 1.96 * strata_IS_est$se, ytop = 0.4,
                 col = colors[10], border = NA)
            }
        }
        ## IS
        rect(xleft = IS_est$est - 1.96 * IS_est$se, ybottom = 0.1,
             xright = IS_est$est + 1.96 * IS_est$se, ytop = 0.3,
             col = colors[12], border = NA)
        abline(v = truth, lwd = 3)
        legend(par()$usr[1], 1.2, pch = c(rep(15, 4), NA), lty = c(rep(NA, 4), 1), lwd = c(rep(NA, 4), 3),
               pt.cex = 3, col = c(colors[c(5, 7, 12, 10)], "black"), 
               horiz = T, bty = "n", xpd = T, y.intersp = 2, 
               legend = c("simple MC", "stratified MC", "IS", "stratified IS", "exact value"))
    })
}

# Run the application  ----
shinyApp(ui = ui, server = server)
