library(shiny)
# ui ----
ui <- fluidPage(

    fluidRow(
        column(
            width = 3,
            ## data, overall settings ----
            h3("Data"),
            radioButtons("data_type",
                         "Type of data:",
                         c("Gaussian" = "Gaussian",
                           "Bi-modal" = "bimodal",
                           "Banana-shaped" = "banana")),
            sliderInput("n",
                        "Number of data points:",
                        min = 0,
                        max = 5e3, step = 10,
                        round = T, 
                        value = 300),
            ## questions ----
            p("1. Which type of plot (panels 1-4) do you think is most informative about the underlying distribution of the data? Why?"), 
            p("2. Which type of histogram (panels 2-4) is most effective for a small number of bins? Why?"),
            p("3. Which type of histogram (panels 2-4) would you be most inclined to use as a communication tool for a non-statistical audience? Which would you be least inclined to use? Why?"),
            p("4. Is there an all-around best plot (panels 1-4)? An all-around worst?"),
            p('5. What is one thing you noticed from your explorations that you think others may not have noticed?')
        ),
        ## plot settings ----
        column(
            width = 9,
            fluidRow(
                ## scatter plot ----
                column(
                    width = 6,
                    fluidRow(
                        h3("Transparent scatter plot"),
                        tabsetPanel(
                            type = "tabs", 
                            tabPanel(
                                "Options",
                                sliderInput("transparency",
                                            "Transparency of points:",
                                            min = 0,
                                            max = 1,
                                            value = 0.5),
                                sliderInput("pt_size",
                                            "Size of points:",
                                            min = 0,
                                            max = 3,
                                            step = 0.1,
                                            value = 1)
                            ), 
                            tabPanel(
                                "Code", 
                                code('library(scales)'), br(),
                                code('Z <- gen_data()'), br(),
                                code('plot(Z, col = alpha("black", alpha), 
                                     pch = 16, cex = pt_cex, asp = 1)')
                            )
                        )
                    ),
                    fluidRow(
                        plotOutput("transPlot")
                    )
                ),
                ## rectangular ----
                column(
                    width = 6,
                    fluidRow(
                        h3("Rectangular histogram"),
                        tabsetPanel(
                            type = "tabs",
                            tabPanel(
                                "Options",
                                sliderInput("xbin",
                                            "Number of horizontal bins:",
                                            min = 0,
                                            max = 100,
                                            value = 25),
                                sliderInput("ybin",
                                            "Number of vertical bins:",
                                            min = 0,
                                            max = 100,
                                            value = 25)
                            ), 
                            tabPanel(
                                "Code",
                                code('library(gplots)'), br(),
                                code('Z <- gen_data()'), br(),
                                code('hist2d(Z, nbins = nbins_rect, 
                                     col = gray.colors(1e2, start = 1, end = 0.1), asp = T')
                            )
                        )
                    ),
                    fluidRow(
                        plotOutput("rectPlot")
                    )
                )
            ),
            fluidRow(
                ## hexagonal ----
                column(
                    width = 6,
                    fluidRow(
                        h3("Hexagonal histogram"),
                        tabsetPanel(
                            type = "tabs",
                            tabPanel(
                                "Options",
                                sliderInput("nbin_hex",
                                    "Number of bins:",
                                    min = 0,
                                    max = 500,
                                    value = 100)
                            ),
                            tabPanel(
                                "Code",
                                code('library(hexbin)'), br(),
                                code('Z <- gen_data()'), br(),
                                code('h <- hexbin(x = Z[, 1], y = Z[, 2], 
                                     xbins = sqrt(nbins_hex))'), br(),
                                code('plot(h, legend = F)')
                            )
                        )
                    ),
                    fluidRow(
                        plotOutput("hexPlot")
                    )
                ),
                ## tessellation ----
                column(
                    width = 6,
                    fluidRow(
                        h3("Random tessellation histogram"),
                        tabsetPanel(
                            type = "tabs",
                            tabPanel(
                                "Options",
                                sliderInput("nbin_tess",
                                            "Number of bins:",
                                            min = 0,
                                            max = 500,
                                            value = 50),
                                radioButtons("tess_model",
                                             "Arrangement of tessellation:",
                                             c("Regular grid" = "regular",
                                               "Uniform on rectangular range of data" = "unif",
                                               "Gaussian with sample mean and covariance" = "Gaussian"), 
                                             selected = "unif"),
                                checkboxInput("show_grid", 
                                              "Show grid?",
                                              value = TRUE)
                            ),
                            tabPanel(
                                "Code",
                                code('library(deldir)'), br(),
                                code('Z <- gen_data()'), br(),
                                code("you don't wanna know")
                            )
                        )                        
                    ),
                    fluidRow(
                        plotOutput("tessPlot")
                    )
                )
            )
        )
    )
)

# server ----
server <- function(input, output) {
    ## libraries ----
    require(mvtnorm)
    require(scales)
    require(spatstat)
    require(gplots)
    require(hexbin)
    require(deldir)
    ## helpers ----
    func <- function(x){
        6 * (x - 0.5)^2 + 0.25
    }
    lambda <- function(x, y){
        exp((-(func(x) - y)^2 * 2e1 - (x - 0.4)^2 * 5) * 4)
    }
    make_regular_grid <- function(n, bb = c(0, 1, 0, 1)){
        w <- diff(bb[1:2]); l <- diff(bb[3:4])
        n_x <- ceiling(sqrt((n * sqrt(3) * w) / (2 * l)))
        x <- w / (n_x - 1)
        n_y <- 2 * ceiling(l / (x * sqrt(3) / 2) / 2)
        origin <- bb[c(1, 3)] - c(x / 4, (n_y * x * sqrt(3) / 2 - l) / 2)
        cbind(origin[1] + rep(c(1:n_x - 1, 1:n_x - 0.5), ceiling(n_y/2)) * x,
              origin[2] + rep(1:n_y - 1, rep(n_x, n_y)) * x * sqrt(3)/2)
    }
    ## generate data ----
    gen_data <- reactive({
        n <- input$n
        if(input$data_type == "Gaussian") {
            rmvnorm(n, mean = c(0, 0), sigma = matrix(c(1, -0.8, -0.8, 1), 2, 2))
        } 
        else if(input$data_type == "bimodal") {
            data <- rbind(rmvnorm(floor(n / 2), mean = c(0, 0), 
                                  sigma = matrix(c(1, -0.4, -0.4, 1), 2, 2)),
                          rmvnorm(ceiling(n / 2), mean = c(3, 6), 
                                  sigma = matrix(3 * c(1, 0.7, 0.7, 1), 2, 2)))
            data
        } 
        else if(input$data_type == "banana") {
            data <- rpoint(n = n, f = lambda)
            cbind(data$x, data$y)
        }
    })
    ## scatter plot ----
    get_transparency <- reactive({
        input$transparency
    })
    get_pt_size <- reactive({
        input$pt_size
    })
    output$transPlot <- renderPlot({
        Z <- gen_data()
        alpha <- get_transparency()
        pt_cex <- get_pt_size()
        plot(Z, xlab = "", ylab = "", xaxt = "n", yaxt = "n", 
             col = alpha("black", alpha), 
             pch = 16, cex = pt_cex, asp = 1)
    })
    ## rectangular ----
    get_nbins_rect <- reactive({
        c(input$xbin, input$ybin)
    })
    output$rectPlot <- renderPlot({
        Z <- gen_data()
        nbins_rect <- get_nbins_rect()
        hist2d(Z, nbins = nbins_rect, col = gray.colors(1e2, start = 1, end = 0.1), 
               asp = T, xaxt = "n", yaxt = "n", xlab = "", ylab = "")
    })
    ## hex ----
    get_nbins_hex <- reactive({
        input$nbin_hex
    })
    output$hexPlot <- renderPlot({
        Z <- gen_data()
        nbins_hex <- get_nbins_hex()
        h <- hexbin(x = Z[, 1], y = Z[, 2], xbins = sqrt(nbins_hex))
        plot(h, legend = F, xaxt = "n", yaxt = "n", xlab = "", ylab = "")
    })
    ## tess ----
    get_nbins_tess <- reactive({
        input$nbin_tess
    })
    get_tess_model <- reactive({
        input$tess_model
    })
    get_show_grid <- reactive({
        input$show_grid
    })
    gen_grid <- reactive({
        Z <- gen_data()
        nbins_tess <- get_nbins_tess()
        tess_model <- get_tess_model()
        if(tess_model == "Gaussian") {
            grid <- rmvnorm(nbins_tess, mean = colMeans(Z), sigma = cov(Z))
        } else if(tess_model == "unif") {
            grid <- cbind(runif(nbins_tess, min(Z[, 1]), max(Z[, 1])),
                          runif(nbins_tess, min(Z[, 2]), max(Z[, 2])))    
        } else if(tess_model == "regular") {
            grid <- make_regular_grid(nbins_tess, c(range(Z[, 1]), range(Z[, 2])))
        }
        grid
    })
    output$tessPlot <- renderPlot({
        Z <- gen_data()
        nbins_tess <- get_nbins_tess()
        show_grid <- get_show_grid()
        grid <- gen_grid()
        nbins_tess <- nrow(grid)
        grid_ind <- apply(Z, 1, function(Z_i){
            which.min(colSums((t(grid) - Z_i)^2))
        })
        table_grid <- table(sort(grid_ind))
        n_in_grid <- rep(0, nbins_tess)
        n_in_grid[as.numeric(names(table_grid))] <- table_grid
        ##
        grid_deldir <- deldir(grid[, 1], grid[, 2])
        grid_tilelist <- tile.list(grid_deldir)
        color_function <- colorRamp(c("white", "black"))
        heights <- sapply(1:nbins_tess, function(i) n_in_grid[i]/nrow(Z)/grid_tilelist[[i]]$area)
        max_heights <- max(heights)
        plot(Z, type = "n", xaxt = "n", yaxt = "n", xlab = "", ylab = "", asp = 1)
        for(i in 1:nbins_tess){
            polygon(grid_tilelist[[i]], border = NA,
                    col = rgb(color_function(heights[i] / max_heights) / 255))
        }
        if(show_grid) points(grid, pch = 16, cex = 0.6)
    })

}

# Run the application 
shinyApp(ui = ui, server = server)
