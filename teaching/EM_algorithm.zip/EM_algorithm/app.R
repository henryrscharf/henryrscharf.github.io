library(shiny)

# ui ----
ui <- fluidPage(
    withMathJax(),
    tags$div(HTML("<script type='text/x-mathjax-config'>
                MathJax.Hub.Config({
                tex2jax: {inlineMath: [['$','$'], ['\\(','\\)']]}
                });
                </script>")),
    h1("Expectation maximization for Gaussian mixture models"),
    h4("Henry Scharf"),
    fluidRow(
        ## Instructions ----
        column(
            width = 4,
            h3("Instructions:"),
            p("This shinyapp is an attempt to reveal how the EM algorithm for fitting a two-component Gaussian mixture model works. The EM algorithm alternates between two steps:"),
            HTML("<ol style='list-style-type: lower-roman;'>
            <li>Given a set of model parameters, $\\mu_1, \\mu_2, \\sigma_1, \\sigma_2, p$, compute the <strong>expected</strong> value of all $z_j$, which is the probability that each observation $j$ came from component 1 $($vs. component 2$)$</li> 
            <li>Given the set of probabilities for component membership just calculated in i., compute the values of all model parameters that <strong>maximize</strong> the log-likelihood for the data.</li></ol>"),
            p("In this interactive tool, you will be responsible for carrying out step ii. That is, given some probabilities assigned to each observation $($shown as colors in the figure to the right$)$, you must try to find the optimal parameter values. The algorithm is initialized with random parameter values. You can set the mean, $\\mu_1$, standard deviation, $\\sigma_1$, and mixture weight, $p$, by brushing $($clicking and dragging$)$ with your mouse. The location of the brushed box adjusts the mean, the width of the box adjusts the standard deviation, and the height of the box adjusts the mixture weight. Your goal when setting these parameters is to make your components ", em("agree"), " with the colors of the points."),
            p("Once you've settled on the parameters associated with the first component, click ", code("Set single component"), " and do the same for the second component. You'll notice that changing the mixture weight for one component necessarily adjusts the other to ensure they sum to 1."),
            p("Once you have settled on the parameters for both mixture components, click ", code("Set both components"), " to have R perform step i and color the points along the bottom of the plot according to the expected values of component membership. Then, adjust your parameters by repeating ii.")
        ),
        ## plot settings ----
        column(
            width = 8,
            ## questions ----
            h3("Questions:"),
            p("1. Try iterating with R a few times by matching the component shapes to the colorings. Make sure you pay attention to the widths of your distributions. When you can no longer increase the log-likelihood, click ", code("Show truth") ,". How did you do?"),
            p("2. This EM algorithm is supposedly robust. Try starting out with a really terrible set of components, but then following the rules for matching the colors from step i. Does your algorithm still converge? Can you break it?"),
            p("3. What's one thing about the EM algorithm that this shinyapp made clearer? What's one thing it made less clear?"),
            p("4. What's one thing about this shinyapp that you think others might not have noticed?"),
            ## EM plot ----
            fluidRow(
                plotOutput("EMPlot", brush = "brush_range")
            ),
            actionButton("restart", code("Restart")),
            actionButton("set_single", code("Set single component")),
            actionButton("set_both", code("Set both components")),
            ## ll plot ----
            fluidRow(
                plotOutput("llPlot")
            ),
            h3("Warning: spoilers!"),
            actionButton("show_hist", code("Show histogram")),
            actionButton("show_truth", code("Show truth")),
        )
    )
)



# Define server logic required to draw a histogram
server <- function(input, output) {
    ## helpers ----
    colors <- c("#701c00", "#8c3800", "#a85400", "#c47000", "#c48c1c",
                "#e0a81c", "#e0c48c", "#e0e0e0", "#c4c4c4", "#8ca8c4",
                "#708ca8", "#1c54a8", "#385438", "#38381c")[c(5, 10)]
    mixture_ll <- function(x, mus, sigmas, p, log = T){
        out <- sum(log(p * dnorm(x, mus[1], sigmas[1]) +
                           (1 - p) * dnorm(x, mus[2], sigmas[2])))
        if(!log) return(exp(out))
        return(out)
    }
    x_seq <- seq(-6, 6, l = 3e2)
    n <- 1e2
    mus <- c(-2, 2)
    sigmas <- c(1, 1.5)
    p <- 0.7
    truth <- reactiveValues(mus = c(-2, 2), sigmas = c(1, 1.5), p = 0.7)
    params <- reactiveValues(mu = runif(2, -2, 2), sigma = c(1, 1), p = c(0.5, 0.5), x = NULL, z = NULL,
                             group_index = 0, z_col = rep("black", n), ll = NULL, show_hist = F, show_truth = F, seed = 2020)
    ## ----
    observeEvent(input$restart, {
        params$mu <- runif(2, -1, 1)
        params$sigma <- c(1, 1)
        params$p <- c(0.5, 0.5)
        params$group_index <- 0
        params$z_col <- rep("black", n)
        params$show_hist <- F
        params$show_truth <- F
        params$seed <- params$seed + 1
        set.seed(params$seed)
        truth$mus <- runif(2, -3, 3)
        truth$sigmas <- runif(2, 0.5, 2)
        truth$p <- runif(1, 0.2, 0.8)
        params$z <- sample(1:2, size = n, prob = c(truth$p, 1 - truth$p), replace = T)
        params$x <- rnorm(n, mean = truth$mus[params$z], sd = truth$sigmas[params$z])
        gamma <- sapply(1:2, function(g) params$p[g] * dnorm(as.numeric(params$x), mean = params$mu[g], sd = params$sigma[g]))
        params$z_col <- rgb(colorRamp(colors = colors)(gamma[, 2] / rowSums(gamma)), m = 255)
        params$ll <- mixture_ll(x = params$x, mus = params$mu, sigmas = params$sigma, p = params$p[1], log = T)
    }, ignoreNULL = F)
    observeEvent(input$brush_range$xmin, {
        params$mu[params$group_index + 1] <- (input$brush_range$xmin + input$brush_range$xmax) / 2
        params$sigma[params$group_index + 1] <- (input$brush_range$xmax - input$brush_range$xmin) / 2 / qnorm(0.975)
        params$p[params$group_index + 1] <- min(1, (input$brush_range$ymax - input$brush_range$ymin) / 0.35)
        params$p[2 - params$group_index] <- 1 - params$p[params$group_index + 1]
    })
    observeEvent(input$set_single, {
        params$group_index <- (params$group_index + 1) %% 2
    })
    observeEvent(input$set_both, {
        gamma <- sapply(1:2, function(g) params$p[g] * dnorm(as.numeric(params$x), mean = params$mu[g], sd = params$sigma[g]))
        params$z_col <- rgb(colorRamp(colors = colors)(gamma[, 2] / rowSums(gamma)), m = 255)
        params$ll <- c(params$ll, mixture_ll(x = params$x, mus = params$mu, sigmas = params$sigma, p = params$p[1], log = T))
    }, ignoreNULL = F)
    observeEvent(input$show_hist, {
        if(isTRUE(params$show_hist)) params$show_hist <- F else params$show_hist <- T
    })
    observeEvent(input$show_truth, {
        if(isTRUE(params$show_truth)) params$show_truth <- F else params$show_truth <- T
    })

output$EMPlot <- renderPlot({
        if(!isTRUE(params$show_hist)){
            hist_col <- hist_bord <- NA
        } else {
            hist_col <- "lightgray"; hist_bord <- "black"
        }
        hist(params$x, freq = F, breaks = 20, col = hist_col, border = hist_bord, xlab = "x", main = "")
        for(g in 1:2){
            lines(x_seq, params$p[g] * dnorm(x_seq, mean = params$mu[g], sd = params$sigma[g]), col = colors[g], lwd = 3)
        }
        points(params$x, rep(0 - diff(par()$usr[3:4]) * 0.02, n), col = params$z_col, pch = 1, cex = 2, xpd = T, lwd = 2)
        if(isTRUE(params$show_truth)){
            opt <- optim(par = c(quantile(params$x, probs = c(0.25, 0.75)), 1, 1, 0.5), fn = function(par){
                -mixture_ll(x = params$x, mus = par[1:2], sigmas = par[3:4], p = par[5])
            })
            for(g in 1:2){
                prob <- opt$par[5]; if(g == 2) prob <- 1 - opt$par[5]
                lines(x_seq, prob * dnorm(x_seq, mean = opt$par[g], sd = opt$par[2 + g]), lwd = 5, lty = 2)
            }
        }
    })
    output$llPlot <- renderPlot({
        if(!is.null(params$ll)) 
            plot(tail(params$ll, 5), type = "l", ylab = "log-likelihood", xlab = "iteration")
        if(isTRUE(params$show_truth)){
            opt <- optim(par = c(-1, 1, 1, 1, 0.5), fn = function(par){
                -mixture_ll(x = params$x, mus = par[1:2], sigmas = par[3:4], p = par[5])
            })
            plot(tail(params$ll, 5), type = "l", ylab = "log-likelihood", xlab = "iteration", 
                 ylim = range(tail(params$ll, 5), -opt$value))
            abline(h = -opt$value, lty = 2, lwd = 3)
        }
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
